package com.cap.anurag.service;

import com.cap.anurag.entities.Employee;

public interface EmployeeService {

	Employee update(Employee employee);

}
